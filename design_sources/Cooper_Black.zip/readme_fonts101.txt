﻿This file is downloaded from fonts101.com, all fonts on the website are available for free and may not be resold. 

Credits to original creators. Let us know how we can serve you better @ fonts101.com

Visit http://www.fonts101.com
